package Client;

import Server.Game;
import Server.User;

public class UserInfo {
    public static User user;
    public static int game = -1;
}
