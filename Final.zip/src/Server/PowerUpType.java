package Server;

import java.io.Serializable;

public enum PowerUpType implements Serializable {
    heal,
    shield,
    damage2,
    damage3
}
