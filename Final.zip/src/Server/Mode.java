package Server;

public enum Mode {
    DEATH_MATCH,
    SHOWDOWN
}
