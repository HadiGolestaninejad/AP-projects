package Components;

public enum TankColor {
    blue,sand,dark,red,green
}
